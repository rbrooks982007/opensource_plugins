
var legend = [
  'Sliders have a "valueTip" and a "quickTip" property.',
  'Both can be used at the same time, as in the last example.',
  'You can set the "type" property to "linear" or "discrete".',
  'And determine the number of steps for the "discrete" type.',
  'You can set the initial position to "start", "middle" or "end".',
  'Sliders are easily configurable to get any imaginable look.'
];

(function() {
  var g = $C({element : "g", transform : "translate(410 450)", "font-size" : "8pt", appendTo : pergola.user}),
      t = $C({element : "text", appendTo : g});
  for (var a in legend) $C({element : 'tspan', x : 0, dy : 16, textNode : legend[a], appendTo : t});
})();
