
//=======================   Pergola examples - D3 multiple documents - force.js   =====================


var forceWin = new pergola.Window("D3 Force-Directed Graph");

/* DS-
 * Cleanest way to encapsulate in window:
 * Define a helper function as instance method for the "contains" property
 * of the window object. The D3 example script is the body of the function.
*/
forceWin.contents = function() {
  var w = 960,
	    h = 500,
      fill = d3.scale.category20(),
      o = this,
      force, link, node;

// DS- replace <svg> with <g> (BBox needed).
  var vis = d3.select(this.childDoc.transformable)
    .append("svg:g");

// DS- sets a stable BBox
	$C({element: "rect", width: w, height: h, fill: "none", "pointer-events": "none", appendTo: vis.node()});
/*
 * DS- For some unidentified reason the line nodes trigger the event
 * systematically, but the circle nodes only erratically.
*/
//  vis.node().addEventListener("mousedown", xWindowinteractivityExample, false);

  d3.json("miserables.json", function(json) {
    force = d3.layout.force()
        .charge(-120)
        .linkDistance(30)
        .nodes(json.nodes)
        .links(json.links)
        .size([w, h])
        .start();
  
    link = vis.selectAll("line.link")
        .data(json.links)
      .enter().append("svg:line")
        .attr("class", "link")
        .attr("opacity", function(d) { return Math.sqrt(d.value) / 10; })
        .attr("x1", function(d) { return d.source.x; })
        .attr("y1", function(d) { return d.source.y; })
        .attr("x2", function(d) { return d.target.x; })
        .attr("y2", function(d) { return d.target.y; });
  
    node = vis.selectAll("circle.node")
        .data(json.nodes)
      .enter().append("svg:circle")
        .attr("class", "node")
        .attr("cx", function(d) { return d.x; })
        .attr("cy", function(d) { return d.y; })
        .attr("r", 5)
        .attr("fill", function(d) { return fill(d.group); })
        .call(force.drag);
  
    node.append("svg:title")
        .text(function(d) { return d.name; });
  
    vis.transition()
        .duration(1000);

    function xWindowinteractivityExample(evt) {
      evt.stopPropagation;
      streamWin.transition(streamWin.transitTo, evt.target.getAttributeNS(null, "fill"));
    }

// Registering evnts on the circle nodes individually (see comment at line 27).
    for (var a in node[0]) node[0][a].addEventListener("mousedown", xWindowinteractivityExample, false);

    force.on("tick", function() {
      link.attr("x1", function(d) { return d.source.x; })
          .attr("y1", function(d) { return d.source.y; })
          .attr("x2", function(d) { return d.target.x; })
          .attr("y2", function(d) { return d.target.y; });
  
      node.attr("cx", function(d) { return d.x; })
          .attr("cy", function(d) { return d.y; });
    });
  });
};




forceWin.build({
  width: 570,
  height: 440,
  contains: function() {return this.contents()}
});
