
//======================   Pergola examples - colorpicker and ColorBoxSelector   ========================



/*
 * Pergola builds an instance of the ColorPicker class, pergola.colorpicker, which can be used
 * by any object. The object initializes the colorpicker by invoking its init() method which
 * expects one object as argument with the "user" and "color" properties set (see documentation).
 *
 * In this example the object is an instance of the ColorBoxSelector class, which is designed
 * specifically to use the colorpicker.
*/

var g = $C({element : "g", transform : "translate(100 50)", appendTo : pergola.user});

var mySelector = new pergola.ColorBoxSelector();
mySelector.build({
  parent : g,
  caption : {
    text : {
      x : -6,
      y : 15,
      textNode : "Select color",
      "pointer-events" : "none"
    }
  },
  target : pergola.background,
  fn : function () {
    var cp = pergola.colorpicker,
        user = cp.user;
        color = cp.color;
    user.fill = color;
    user.rect.setAttributeNS(null, "fill", color);
// example : change the background color
//    user.target.fill = color;
//    user.target.rect.setAttributeNS(null, "fill", color);
  }
});


/*
 * You can create other ColorPicker instances but only one instance at a time can be used.
 * In effect the "isUp" property is a class property, not an instance property. This boolean
 * is tested right off in the init() method and if true, the initialization is aborted.
*/
