
//==========================   Pergola examples - panel with combobox   ==========================




/*
 * comboboxes are usally found in dialogs, and selections ara validated by a doubleclick or the
 * dialog's OK button, while the cancel button cancels the selection, so we build a dialog panel
 * and have it use the Layout class to create the combobox instance, referenced by the "combobox"
 * property of the panel. The list "myList" used by the combobox is defined in the "list" file.
 *
 * To see how to address directly the ComboBox constructor for a standalone instance, see the
 * standalone_combo.svg example.
*/


var myPanel = new pergola.Panel("my panel");
myPanel.build({
  title : "PANEL WITH COMBO BOX",
  x : 150,
  y : 50,
  okButton : {
    text : "OK"                  // this is the default value. Redundant
  },
  cancelButton : {
    text : "Cancel"              // this is the default value. Redundant
  },
  fn : "listItemFunc",
  display : "block",             // panels are mostly used for dialogs. The display is set to "none" by default
  layout : {
    type : "combobox",           // the name of a prototype method of the Layout class
    y : 60,
    list : myList
  },
// For this demo we want the panel to remain open. Let's override its prototype method closeControl()
  closeControl : function (evt) {
    var string = "For the purpose of this demo the closeControl \nprototype method was overridden to show this \nmessage and leave the panel open.";
    var t = evt.target;
    if (t == this.close.button || t == this.cancel.button) $M(string, {x : 300, y : 220});
  }
});


/*
 * a simple user function for combobox list items
*/
myPanel.listItemFunc = function (evt) {
  var handle = this.comboBox.selectionHandle;
  if (handle) {
    for (var m in myList) {
      if (handle.string == myList[m]) $M(myMessages[m], {x : 300, y : 220});
    }
  }
}



/*
 * You can add this line in contents update functions (if the combobox has updatable contents)
 * for svg implementations that don't have mutation events implemented (ASV).
*/
// if (!pergola.mutationEvnt) myPanel.combobox.childDoc.updateOnMutationEvent();

