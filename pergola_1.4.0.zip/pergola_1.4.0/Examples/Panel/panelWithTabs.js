
//=============================   Pergola examples - panel with tabs and layout   ==========================




var tabbed = new pergola.Panel("tabbed panel");


/*
 * The prototype property "pane" of the Tab class is set to false. A tabbed panel overrides it to true and
 * builds a pane, for each tab. The tab's "pane" property then mutates to become a reference to the actual
 * pane (group). We append our contents to the pane. By using a function to append contents to the pane we
 * have access to the tab's and panel's geometrical -and all other- properties for our tab contents layout.
 * Note that the functions referenced by the 'fn' properties of the tabs are helpers and must be already
 * defined, or alternatively be prototype methods or defined inline, as you will find appropriate.
 * The real User Functions will be defined by the objects that you will use in your tabs.
 *
 * We define the helper functions first, showing one of the advantages of the split method used by Pergola
 * for creating instances (see the doc):
 * 1) call to constructor -> inheritance
 * 2) call to the build() method -> opportunity to define properties in between and to place the call in a
 * different file, or executed dynamically on certain types of events; capability of self-reference.
*/


tabbed.tab2Contents = function () {
  $C({element : "text", x : this.owner.width / 2, y : 200, 'font-size' : 120, "font-weight" : "bold", fill : "#F0F0F0", 'text-anchor' : "middle", textNode : this.title.toUpperCase(), appendTo : this.pane});
}

tabbed.tab3Table = function () {
  for (var c in this.cells) {
    $C({element : "text", x : this.layout.cellWidth / 2, y : this.layout.cellHeight / 2 + 8, 'font-size' : "16pt", "font-weight" : "bold", fill : "#F0F0F0", 'text-anchor' : "middle", textNode : "CELL " + c, appendTo : this.cells[c]});
  }
}


/*
 * Works with:
 * Firefox: correctly (least some style)
 * Webkit: partially
 * Opera: no
 * ASV: no (foreignObject not implemented)
 * IE9: no (foreignObject not implemented)
*/

tabbed.tab1HTML = function () {
  var fObj = $C({element : "foreignObject", width : this.paneWidth, height : this.paneHeight, appendTo : this.pane});
  var body = pergola.createHTMLElement({element : "body", appendTo : fObj});
  var table = pergola.createHTMLElement({element : "table", border : 1, cellpadding : 2, cellspacing : 2, style : "width: 100%; background-color: #F8F8F8;", appendTo : body});
  for (var i = 0; i < 3; i++) {
    var tr = pergola.createHTMLElement({element : "tr", appendTo : table});
    for (var j = 0; j < 3; j++) {
      var td = pergola.createHTMLElement({element : "td", style : "height: " + ((this.paneHeight - 30) / 3) + "px; text-align: center;", appendTo : tr});
      var p = pergola.createHTMLElement({element : "p", style : "font-size: 16pt; font-weight: bold; color: #F0F0F0;", textNode : ("CELL " + (i * 3 + j)), appendTo : td});
    }
  }
// the <switch> element (scripted) doesn't quite make it. Workaround
  if (pergola.browser.asv) $C({element : "text", x : this.paneWidth / 2, y : this.paneHeight / 2 + 8, 'font-size' : "10pt", "font-weight" : "bold", fill : "#606060", 'text-anchor' : "middle", textNode : "This implementation does not support foreignObject", appendTo : this.pane});
}


tabbed.build({
  type : "dialog",
  title : "PANEL WITH TABS",
  x : 100,
  y : 100,
  width : 600,
  height : 440,
  okButton : {
    text : "OK"
  },
  cancelButton : {
    text : "Cancel"
  },
  display : "block",                 // panels are mostly used for dialogs. The "display" property defaults to "none"
  layout : {
    type : "tabbed",                 // the name of a Layout prototype method
    tabs : {
      tab1 : {
        active : false,
        title : "html",
        fn : tabbed.tab1HTML         // helper function
      },
      tab2 : {
        active : true,
        title : "tab # 2",
        fn : tabbed.tab2Contents             // helper function
      },
      tab3 : {
        active : false,
        title : "layout",
        layout : {
          type : "table",                    // the name of a Layout prototype method
          x : 12,
          y : 12,
          rows : 3,
          cols : 3,
          spacing : 4,                       // Number - inherited units only
          attributes : {                     // Any <rect> attributes go here
            fill : "#F8F8F8",
            stroke : "#D0D0D0",
            'stroke-width' : 1               // we suggest using only screen units: px or pt. (this property is redundant)
          }
        },
        fn : tabbed.tab3Table                // helper function
      }
    }
  }
});


$C({element : "text", x : 40, y : 40, 'font-size' : "8pt", textNode : "* The html table in the first tab works well for Firefox only", appendTo : pergola.user});






