
//=============================   Pergola examples - panel with table layout   ==========================



var myPanel = new pergola.Panel("My panel");



// Helper function for populating the panel
myPanel.contents = function () {
  var obj = this.owner;
  for (var c in obj.cells) {
    $C({element : "text",
      x : obj.layout.cellWidth / 2,
      y : obj.layout.cellHeight / 2 + 8,
      'font-size' : "16pt",
      "font-weight" : "bold",
      fill : "#F0F0F0",
      'text-anchor' : "middle",
      textNode : "CELL " + c,
      appendTo : obj.cells[c]
    });
  }
}



myPanel.build({
  type : "dialog",
  title : "PANEL WITH TABLE LAYOUT",
  x : 100,
  y : 50,
  width : 600,
  height : 440,
  okButton : {
    text : "OK"                  // text is most often configurable, but not for DialogButton. Don't assign a text object here
  },
  cancelButton : {
    text : "Cancel"
  },
  display : "block",             // panels are mostly used for dialogs. The "display" property defaults to "none"
  layout : {
    type : "table",              // the name of a Layout prototype method
    x : 12,                      // Number only (exception for table) - inherited units only
    y : 12,                      // Number ...
    rows : 2,
    cols : 2,
    spacing : 4,                 // Number - inherited units only
    attributes : {               // Any <rect> attributes go here
      fill : "#F8F8F8",
      stroke : "#D0D0D0",
      'stroke-width' : 1         // we suggest using only screen units: px or pt. (this property is redundant)
    },
    fn : myPanel.contents        // helper function
  }
});


// Alternate to helper function
/*
(function() {
  var panel = myPanel;
  for (var c in panel.cells) {
    $C({element :"text", x :panel.layout.cellWidth / 2, y :panel.layout.cellHeight / 2 + 8, 'font-size' :"16pt", "font-weight" :"bold", fill :"#F4F4F4", 'text-anchor' :"middle", textNode :"CELL " + c, appendTo :panel.cells[c]});
  }
})();
*/

