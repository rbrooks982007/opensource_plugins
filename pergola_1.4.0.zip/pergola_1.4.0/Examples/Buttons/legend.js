
legend({
	tip1: "The basic button is a rectangle and has two preset sizes.",
	tip2: "You can define your own shape or use a shape from the library.",
	tip3: "The user define shape can be any SVG primitive shape.",
	tip4: "You can add any property as element attribute using SVG syntax.",
	tip5: "You can easily change the fill (hover) and/or the mask fill.",
	tip6: "You can define the tranform property using SVG syntax.",
	tip7: "Symbols can be scaled and filled to your needs.",
	tip8: "You position a symbol by setting its x and y properties.",
	tip9: "Or simply specify \"center\" for either one or both.",
	tip10: "You can place text and a symbol together in the same button.",
	tip11: "You can define any properties for the text property object",
	tip11a: "as text element attributes using SVG syntax.",
	tip12: "You can also assign an image besides the fill property.",
	tip13: "Symbols can be artwork or images and you can set their opacity."
});




function legend() {
	var g = $C({element: "g", transform: "translate(140 420)", "font-size": "8pt", appendTo: pergola.user}),
			t = $C({element: "text", y: 0, appendTo: g});

	for (var p in arguments[0]) legend[p] = $C({element: 'tspan', x: 0, dy: 16, textNode: arguments[0][p], appendTo: t});

	legend.hilight = function(evt) {
		if (evt.type == "mouseup") {
      if (!this.target.length) this.target = [this.target];
  		for (var a in this.target) this.target[a].setAttributeNS(null, "fill", "red");
  	}
	}
}
