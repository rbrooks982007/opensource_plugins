
//=======================   Pergola examples - popup list selector   =====================




// Let's have a parent node...
var g = $C({element : "g", transform : "translate(150 80)", appendTo : pergola.user});


// and a target object to manipulate
var shirtGroup = $C({element : "g", transform : "translate(420 78)", appendTo : pergola.user});
var tshirt = {
  shape : $C({element : "path", d : "M0 0h14q4.5 4.5,9 0h14v9h-5v24h-27v-24h-5z", fill : "#4080FF", appendTo : shirtGroup}),
  text : $C({element : "text", x : 18.5, y : 14, "font-size" : "5px", "font-weight" : "bold", "text-anchor" : "middle", kerning : 0, fill : "white", textNode : "PERGOLA", appendTo : shirtGroup})
}


mySelector = new pergola.Selector("My Selector");
mySelector.build({
  parent : g,
  list : [
    "Small",
    "Medium",
    "Large",
    "Extra large"
  ],
  index : 0,
  caption : {
    text : {
      x : -9,
      y : 15,
      textNode : "Size",
      'letter-spacing' : 1,
      kerning : 0,
      "pointer-events" : "none"
    }
  },
  target : tshirt,
  fn : function () {
    var t = this.target,
        text = t.text,
        i = this.index;

    t.shape.setAttributeNS(null, "transform", "scale(" + (i + 1) + ")");
    text.setAttributeNS(null, "font-size", (5 * (i + 1)) + "px");
    text.setAttributeNS(null, "x", 18.5 * (i + 1));
    text.setAttributeNS(null, "y", 14 * (i + 1));
    text.setAttributeNS(null, "text-anchor", "middle");
  }
});
