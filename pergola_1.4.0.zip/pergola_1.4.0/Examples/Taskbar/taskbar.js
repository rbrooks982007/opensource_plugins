
//=============================   pergola examples - taskbar   ==========================



myTaskbar = new pergola.Taskbar("myTaskbar");
myTaskbar.build({
  position : "bottom",
  hasMenu : false,
  display : "block"                  // defaults to "none"! (see the doc)
});
