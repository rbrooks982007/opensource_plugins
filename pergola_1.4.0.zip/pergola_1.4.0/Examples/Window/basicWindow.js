
//=============================   Pergola examples - window basic   ==========================



var myWindow = new pergola.Window();
myWindow.build({
  hasCommands : false,
  hasToolBar : false,
  hasZoomAndPan : false,
  hasStatus : false
});
