
legend([
	"The User Functions and Events",
	"mechanism implemented in all",
	"the low level component classes,",
	"together with the possibility of",
	"overriding properties and methods,",
	"allows the addition of accessibility",
	"extensions by developers with the",
	"right know how. They may also find",
	"interesting the possibility to define",
	"a global accessibility “skin”."
]);




function legend() {
	var a = arguments[0],
			t = $C({element: "text", y: 30, "font-size": "12px", display: "none", appendTo: pergola.user});

	for (var l in a) $C({element: 'tspan', x: 580, dy: 16, textNode: a[l], appendTo: t});

	legend.show = function() {
		t.setAttributeNS(null, "display", "block");
	}
}
