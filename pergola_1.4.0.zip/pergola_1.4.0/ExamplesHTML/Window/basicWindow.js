
//=============================   Pergola examples - window basic   ==========================



var myWindow = new pergola.Window();
myWindow.build({
  x : 60,
  y : 50,
  hasCommands : false,
  hasToolBar : false,
  hasZoomAndPan : false,
  hasStatus : false
});
