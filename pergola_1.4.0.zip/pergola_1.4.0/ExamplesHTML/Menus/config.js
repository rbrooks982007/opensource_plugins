
//=============================   Pergola configuration file   =======================

pergola.settings = {

// Use an existing pergola.skins property name
  skin : "rubber",

// Use a color keyword name, a custom color name or specify a color in any legal format.
  theme : "herman"

};

pergola.path = "../../pergola/";

// values: true, false, or the number of lines. Default number of lines is 20.
pergola.debug = false;


/*
 *  Pergola assignes document.documentElement to the doc property as the default container
 *  in a standalone svg context. For use in html context we select the appropriate html element
 *  and we override the doc property.
*/
pergola.container = document.getElementById("svg");
pergola.doc = $C({element : "svg", width : "100%", height : "100%", appendTo : pergola.container});



// DO NOT EDIT BELOW THIS LINE

pergola.defs = $C({element : "defs", id : "pergola_defs", appendTo : pergola.doc});

