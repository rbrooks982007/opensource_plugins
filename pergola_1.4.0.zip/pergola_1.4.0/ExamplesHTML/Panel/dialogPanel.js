
//=============================   pergola examples - dialog panel   ==========================




var myPanel = new pergola.Panel("My Panel");
myPanel.build({
  title : "DIALOG PANEL",
  x : 100,
  y : 50,
  width : 400,
  height : 300,
  okButton : {},                 // The "text" property of this object defaults to "OK"
  cancelButton : {},             // The "text" property of this object defaults to "Cancel"
  display : "block"              // panels are mostly used for dialogs. The "display" property defaults to "none"
});




/*
 * For the okButton and cancelButton objects we can override the "text" and "marginRight" properties.
*/
