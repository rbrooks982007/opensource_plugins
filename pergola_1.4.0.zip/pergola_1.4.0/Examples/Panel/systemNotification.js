
//=============================   Pergola examples - simple panel   ==========================


$M("In the notification string you can use\nthe escape sequence \u005Cn for new lines.", {x : 200, y : 120});

