
//=============================   Pergola examples - simple panel   ==========================



var panel = new pergola.Panel("simple panel");
panel.build({
  title : "SIMPLE PANEL",
  display : "block"              // The "display" property defaults to "none"
});



/*
 * The "type" prototype property of the Panel class is set to "dialog".
 * A panel of this type has a top bar and can have buttons.
 *
 * The "type" property can be overridden with the value "basic".
 * A panel of this type is static, doesn't have buttons, and
 * cannot be closed by the user.
*/
