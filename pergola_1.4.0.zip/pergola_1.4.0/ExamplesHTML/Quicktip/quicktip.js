
//=============================   Pergola examples - quick tip   ==========================



var emptyTool = new pergola.ToolButton();
emptyTool.build({
  x : 240,
  y : 100,
  width : 28,
  height : 22,
  stroke : "sandybrown",
  extra : {
    rx : 6
  },
  quickTip : {
    tip : "Quick–tips can be static or mouse–tracking. |The pop–up delay is configurable globally |and can be overridden. A quick–tip can be a |reference to the library, or can also be defined |on the fly, either as a string or as an array. |More info in the documentation."
  }
});


var spy = new pergola.ToolButton();
spy.build({
  x : 340,
  y : 100,
  width : 38,
  height : 22,
  text : {
    x : 5,
    y : 18,
    'font-size' : 18,
    fill : "white",
    textNode : "007",
    'pointer-events' : "none"
  },
  hasTextEffect : false,
  quickTip : {
    tip : [
      "My name is Bond,",
      "James Bond"
    ],
    x : 378,                   // Fixed position (no mouse tracking)
    y : 68,
    delay : 250                // Override default pop up "delay" (700 ms)
  }
});


/*
 * Alternate formats (see the documentation):
 *
 * String. A check is first carried out:
 * if the string references a property of the pergola.quicktip object (quick-tips library located in qtips.es file)
 * that quicktip is used, otherwise the string is the text of the quicktip. Use the | (vertical bar) for new line.
 *
 * Array of strings.
*/
