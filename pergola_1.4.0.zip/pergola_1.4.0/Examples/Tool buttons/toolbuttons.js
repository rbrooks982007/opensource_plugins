
//=============================   Pergola examples - Tool Buttons   ==========================




var toolBar = new pergola.ToolBar();
  toolBar.build({
  owner : pergola,
  x : 200,
  y : 200,
  width : 420
});


var buttonsGroup = $C({element : "g", transform : "translate(40 3)", appendTo : toolBar.group});


var closeButton = new pergola.CommandButton("close");
closeButton.build({
  parent : buttonsGroup,
  y : 4,
  symbol : {
    symbol : pergola.symbols.winClose,
    x : 5,
    y : 4
  }
});


var emptyTool = new pergola.ToolButton();
emptyTool.build({
  parent : buttonsGroup,
  x : 60,
  width : toolBar.height,
  height : toolBar.height - 6,
  extra : {
    rx : 7
  }
});


// hand tool and zoom tool are selectable. They are handled by an owner object
// with zoomable and scrollable content. See the windows examples.
var handTool = new pergola.ToolButton();
handTool.build({
  parent : buttonsGroup,
  x : 140,
  width : toolBar.height,
  height : toolBar.height - 6,
  extra : {
    rx : 7
  },
  selected : false,
  symbol : {
    symbol : pergola.symbols.hand,
    x : 8,
    y : 7
  },
  quickTip : "handTool"
});


var barrelToolButton = new pergola.ToolButton();
barrelToolButton.build({
  parent : buttonsGroup,
  x : 220,
  width : toolBar.height - 4,
  height : toolBar.height - 6,
  stroke : "peru",
  maskFill : "#E8E8E8",
  extra : {
    rx : 4,
    ry : 11
  },
  quickTip : {tip : "BYOB"}
});


var customToolButton1 = new pergola.ToolButton("customToolButton1");
customToolButton1.build({
  parent : buttonsGroup,
  x : 296,
  width : toolBar.height,
  height : toolBar.height - 6,
  maskFill : "#F0F0F0",
  extra : {
    rx : 7
  },
  stroke : pergola.shade([104.761, 99.009, 91.847], -15),
  symbol : {
    symbol : pergola.path + "lib/symbols/spectrum.png",
    width : 16,
    height : 16,
    x : 6.5,
    y : 4
  }
});
