
//=============================   pergola examples - taskbar   ==========================



myTaskbar = new pergola.Taskbar("myTaskbar");
myTaskbar.build({
  position : "top",                  // values : "top" (initial); "bottom"
  height : 34,
  hasMenu : false,
  display : "block"                  // defaults to "none"! (see the doc)
});
