
//=============================   Pergola examples - ValueInputBox   ==========================




// A parent node
var g = $C({element : "g", transform : "translate(100 50)", appendTo : pergola.user});


// This object is the target of the ValueInputBox
var myObject = {
  r : 0,
  g : 128,
  b : 0,
  circle : $C({element : "circle", cx : 120, cy : 10, r : 16, fill : "rgb(0, 128, 0)", stroke : "#A0A0A0", "stroke-width" : 2, appendTo : g}),
  changeColor : function () {
    this.circle.setAttributeNS(null, "fill", "rgb(" + this.r + "," + this.g + "," + this.b + ")");
  }
};



/*
 * This ValueInputBox acts on the "g" property of its target object.
 * User Function : since several instances of this type of object
 * may be built with the same target, each acting on a particular
 * property, we also need to define the "propName" property, while we
 * do not define the User Event property "ev".
 *
 * The property "realTime" can be set to true for actions that only
 * require little rendering time, like in this example.
*/

myValueBox = new pergola.ValueInputBox();
myValueBox.build({
  owner : myObject,
  parent : g,
  caption : {
    text : {
      x : -16,
      y : 15,
      textNode : "G",
      "pointer-events" : "none"
    }
  },
  max : 255,
  min : 0,
  value : myObject.g,
  target : myObject,
  propName : "g",
  fn : "changeColor",
  realTime : true             // defaults to false
});
